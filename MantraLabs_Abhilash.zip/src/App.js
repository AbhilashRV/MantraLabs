import React , {Component} from "react";
import "./styles.css";

export default class App extends Component {
  
  state ={
    datas:[
      {id:'1', name:'ad'}
    ],
    k:""
  }

  change = (e) =>
  { 
   e.preventDefault();
  // const data:{id:'',name:''}
     let k = e.target.value;
     this.setState({k})
   //  console.log(this.state.k);
    
  }

  delete = (p) =>{
    const datas = this.state.datas.filter(a => a.id!== p.id );
    this.setState({datas});
  }
 
  Submit = (e) => {
    e.preventDefault();
   let j = this.state;
   j.id = Math.random();
   console.log(j);
    
   
    console.log(j.id);
    let datas = [...this.state.datas, {id:this.state.id,name:this.state.k}];
    this.setState({datas });
    console.log(this.state.datas);
  }

  render(){
    //console.log(this.state.data);
  return (
    <div className="App">
  {this.state.data !==0 && this.state.datas.map(a=>{ return (<div key={a.id} onClick={()=>this.delete(a)}>{a.name} </div>)})}
  <form onSubmit={this.Submit}>
      <div>Eneter value
      <input onChange={this.change} />
      </div>
    </form>
    </div>
  );
  }
}
